/* expand.h -- replace bytecode with threaded code */

realcode_t expandcode(bytecode_t byteprog, int code_size, void * jumptable[]);

